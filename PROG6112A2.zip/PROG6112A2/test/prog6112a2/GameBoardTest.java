/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package prog6112a2;

import java.util.Random;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Vinay
 */
public class GameBoardTest {
    
    public GameBoardTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of displayBoard method, of class GameBoard.
     */
    @Test
    public void testDisplayBoard() {
        System.out.println("displayBoard");
        GameBoard instance = new GameBoard();
        instance.displayBoard();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of makeMove method, of class GameBoard.
     */
    @Test
    public void testMakeMove() {
        System.out.println("makeMove");
        int row = 0;
        int col = 0;
        GameBoard instance = new GameBoard();
        boolean expResult = false;
        boolean result = instance.makeMove(row, col);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCurrentPlayer method, of class GameBoard.
     */
    @Test
    public void testGetCurrentPlayer() {
        System.out.println("getCurrentPlayer");
        GameBoard instance = new GameBoard();
        char expResult = ' ';
        char result = instance.getCurrentPlayer();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of switchPlayer method, of class GameBoard.
     */
    @Test
    public void testSwitchPlayer() {
        System.out.println("switchPlayer");
        GameBoard instance = new GameBoard();
        instance.switchPlayer();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkForWin method, of class GameBoard.
     */
    @Test
    public void testCheckForWin() {
        System.out.println("checkForWin");
        GameBoard instance = new GameBoard();
        boolean expResult = false;
        boolean result = instance.checkForWin();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isBoardFull method, of class GameBoard.
     */
    @Test
    public void testIsBoardFull() {
        System.out.println("isBoardFull");
        GameBoard instance = new GameBoard();
        boolean expResult = false;
        boolean result = instance.isBoardFull();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isMoveAvailable method, of class GameBoard.
     */
    @Test
    public void testIsMoveAvailable() {
        System.out.println("isMoveAvailable");
        int row = 0;
        int col = 0;
        GameBoard instance = new GameBoard();
        boolean expResult = false;
        boolean result = instance.isMoveAvailable(row, col);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of makeRandomMoveForO method, of class GameBoard.
     */
    @Test
    public void testMakeRandomMoveForO() {
        System.out.println("makeRandomMoveForO");
        GameBoard instance = new GameBoard();
        instance.makeRandomMoveForO();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRandom method, of class GameBoard.
     */
    @Test
    public void testGetRandom() {
        System.out.println("getRandom");
        GameBoard instance = new GameBoard();
        Random expResult = null;
        Random result = instance.getRandom();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
