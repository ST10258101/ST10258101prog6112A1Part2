/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112a2;
import java.util.Scanner;
 import java.util.Random;
/**
 *
 * @author Vinay
 */
class TicTacToe {

    private GameBoard board;
    private Random random;
    private Scanner scanner;

    public TicTacToe() {
        board = new GameBoard();
        random = new Random();
        scanner = new Scanner(System.in);
    }

    public void startGame() {
        System.out.println("Welcome to Tic-Tac-Toe (Player vs. Computer)!");
        while (true) {
            board.displayBoard();
            int row, col;
            if (board.getCurrentPlayer() == 'X') {
                do {
                    System.out.println("Player " + board.getCurrentPlayer() + ", enter row (0-2) and column (0-2): ");
                    row = scanner.nextInt();
                    col = scanner.nextInt();
                } while (!board.makeMove(row, col));
            } else {
                System.out.println("Player " + board.getCurrentPlayer() + " is making a random move.");
                row = random.nextInt(3);
                col = random.nextInt(3);
                while (!board.isMoveAvailable(row, col)) {
                    row = random.nextInt(3);
                    col = random.nextInt(3);
                }
                board.makeMove(row, col);
            }
            board.switchPlayer();

            if (board.checkForWin()) {
                board.displayBoard();
                System.out.println("Player " + board.getCurrentPlayer() + " wins!");
                break;
            } else if (board.isBoardFull()) {
                board.displayBoard();
                System.out.println("It's a draw!");
                break;
            }
        }
        scanner.close();
        System.out.println("Thanks for playing!");
    }
}
