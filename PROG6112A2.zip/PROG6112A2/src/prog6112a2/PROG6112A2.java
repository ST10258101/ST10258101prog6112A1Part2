/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112a2;

import java.util.Scanner;

/**
 *
 * @author Vinay
 */
public class PROG6112A2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        boolean playAgain;

        do {
            System.out.println("Welcome to Tic-Tac-Toe!");
            System.out.println("""
                               heres a quick tutorial when you pick your position to play
                               you will enter the number of the row ,press enter,
                               then enter the number of the column and then press enter again
                               (everything after that is self explaitory i promise =] )
                               now when selecting the square you want to play in 
                               0 is the first row 
                               1 is the 2nd and
                               2 is the third 
                               the column part follows the same logic so please enjoy =]
                               eg: 1
                                   1
                               is the middle where as 
                                   0
                                   2
                               is the top right
                               """);
            System.out.println("Choose a game mode:");
            System.out.println("1. Player vs. Player");
            System.out.println("2. Player vs. Computer (AI)");
            System.out.println("3. exit");
            System.out.print("Enter your choice (1 or 2 or 3 ): ");
            int choice = scanner.nextInt();

         /*   if (choice == 1) {
                PlayerTicTacToe playerTicTacToe = new PlayerTicTacToe();
                playerTicTacToe.startGame();
            } else if (choice == 2) {
                TicTacToe game = new TicTacToe();
                game.startGame();
            } else {
                System.out.println("Invalid choice. Please enter 1 or 2.");
            } */
         switch (choice) {
    case 1:
        PlayerTicTacToe playerTicTacToe = new PlayerTicTacToe();
        playerTicTacToe.startGame();
        break;
    case 2:
        TicTacToe game = new TicTacToe();
        game.startGame();
        break;
    case 3:
        System.out.println("enter 'no' you want to exit? : ");
        
       
        break;
    default:
        System.out.println("Invalid choice. Please enter 1 or 2.");
        break;
}


            System.out.print("Do you want to play again? (yes/no): ");
            String playAgainInput = scanner.next().toLowerCase();
            playAgain = playAgainInput.equals("yes");

        } while (playAgain);

        System.out.println("Thanks for playing!");
        scanner.close();
    }
}
