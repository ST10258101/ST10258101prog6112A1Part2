/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112a2;
import java.util.Scanner;
/**
 *
 * @author Vinay
 */

public class PlayerTicTacToe {
  
    private GameBoard board;
    private Scanner scanner;

    public PlayerTicTacToe() {
        board = new GameBoard();
        scanner = new Scanner(System.in);
    }

    public void startGame() {
        System.out.println("Welcome to Tic-Tac-Toe (Player vs. Player)!");
        while (true) {
            board.displayBoard();
            int row, col;
            do {
                System.out.println("Player " + board.getCurrentPlayer() + ", enter row (0-2) and column (0-2): ");
                row = scanner.nextInt();
                col = scanner.nextInt();
            } while (!board.makeMove(row, col));
            board.switchPlayer();

            if (board.checkForWin()) {
                board.displayBoard();
                System.out.println("Player " + board.getCurrentPlayer() + " wins!");
                break;
            } else if (board.isBoardFull()) {
                board.displayBoard();
                System.out.println("It's a draw!");
                break;
            }
        }
        scanner.close();
        System.out.println("Thanks for playing!");
    }
}
